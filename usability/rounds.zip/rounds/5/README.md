# Usability study: fifth round

This round ran all eight scenarios with two participants each, `a` and `b`, with `drop` in place of `skip`. The two cohort participants then got the change request in their existing sessions. That makes 16 trials and two follow-ups.

## What this archive holds

[`difficulties.md`](difficulties.md) is the only record kept: the stuck points, guesses, guide gaps, error messages, friction and top three changes from each report, copied without edits. It names a folder of complete reports, `spit-study-participant-reports/`. That folder, the plans, the grades and the call logs were not archived with this round, so this report gives no pass rate and no call counts. What the reports say of their own plans is below, and it is the participants' word, not the grader's.

## What participants reported

- **No participant reported a wrong guess.** Each report says its guesses were confirmed by `spit check`, `--counts` or `--commands`.
- **Job counts the reports give** match their keys: 41 for the ragged sweep, 39 for the single board, 20 for the survey, and 60 for each cohort follow-up. The follow-ups added the new subject without a rule change, added a QC step with a `many` input, and excluded the corrupted run in the recipe. The raw file stayed in place.
- **Two calls failed, both in the vague sensor brief.** Both participants combined `--counts` with `--commands` and got `--counts cannot be used with --commands`. One also wrote a port as `: one` and got `an input takes one artifact unless it says many; write cal`, which it called useful because it gave the fix.

## Findings

1. **The notes on files left out named too little.** Nine reports raised it. The unmatched-file note named one example however many files there were, so the logs and cohort participants listed the rest by hand. The cohort participants asked for a count by extension, since 23 of their 24 files were JSON sidecars. The survey participant pointed out "`1 files`". The note that sources go unused counted them by product, as `(calibration: 3)`, and three participants asked it to name them.
2. **`--counts` would not combine with `--commands`.** Two participants hit the error, and a third asked for both at once.
3. **The joins and rollups were spread across the guide.** Every scenario was solved, but most participants found `where`, `same`, `each` and two levels of `vary` by following links into the language reference and the walkthroughs. Thirteen of the sixteen reports asked for a short combined example near the first pipeline, or a link to a walkthrough beside the first `each`, `drop` or selector. Two asked for a list of checks to run before saving a plan.
4. **A placeholder cannot be narrowed to a date.** Both logs participants looked for a way to make `{date}` match only `YYYY-MM-DD`. There is none, and the guide did not say so.
5. **The port syntax.** One participant expected `port: one`, because `port: many` exists.
6. **Raised once each, not acted on here:** listing the jobs a failed final target holds back, grouped by store (s6); showing identities that differ only in letter case side by side in `inputs` (s6); writing `--commands` and `-o` in one call (s4); having to give an operation and its product different names (s1).

## Changes made in this round

- The unmatched-file note names the files when there are at most three, and otherwise counts them by extension with one example. It says `1 file`.
- The unused-source note in `dag` names the sources when there are at most three.
- `dag --counts` combines with `--commands` and `--paths`, and prints the counts first.
- The README gains "Join, collect, and check the plan" under Write a pipeline. It has one pipeline with `where`, `same`, `port` beside `port: many` and two levels of `vary`, a pointer to the ragged sweep for `each`, and the three commands to check a plan before saving it.
- The language reference says that a source placeholder matches any text within one folder or file name, and how to leave out a file whose value does not belong.

## Next

- Keep the grader's results, call logs and complete reports with the next round, so its pass rate can be compared with earlier rounds.
- The guide each participant reads has links that do not resolve in a sandbox: `spitdag.md#artifact`, `#checks` and `#missing-outputs`, and two links back to the README's sections. `harness/check_guide_links.py` on a sandbox lists them.
- The findings in item 6, if they are raised again.
