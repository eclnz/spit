# Participants’ difficulties, in their own words

These are unedited sections from each participant’s report in the fifth-round study. The complete reports are in `spit-study-participant-reports/`.

## s1-logs-a

## 3. Stuck points

The longest pause was deciding how to express both nested collections without enumerating servers or dates. The text processing example and the reference's `many`/`@ vary(...)` explanation showed that collecting dates removes only the date dimension, then collecting servers removes the final dimension.

## 4. Guesses

I assumed the source path `logs/{server}/{date}.log` would exclude compressed and rotated files and that ISO date strings would sort chronologically. The dataset scan and rendered commands confirmed both for the present files. I also assumed `[server, date]` establishes the collection order; the dimension order section confirmed this. The guide did not confirm that a date placeholder checks the date's format, so that remains a limitation.

## 5. Guide gaps

In GUIDE.md's path discussion and the language reference's paths section, I could not find a way to constrain a captured path value to YYYY-MM-DD. I looked because the task distinguishes daily logs from other files in the same tree.

## 6. Error messages

There were no errors. The product/operation same-name warning was useful and actionable. The note that 3 files "match no source rule and are not read" was useful, though I checked the file list myself to confirm that all three were the intended exclusions.

## 7. Language friction

The pipeline can select the `.log` suffix but I found no way to limit `{date}` to a date-shaped basename. My workaround was to rely on the provided files' names. Otherwise, the `many`/`vary` language fit this pipeline well.

## 9. Top three changes

1. Allow a source path to constrain a placeholder to a simple pattern such as YYYY-MM-DD, or document the existing mechanism clearly if there is one.
2. Add a compact example of two successive `many` aggregations, from per-file to per-group to global output.
3. Make the unmatched-files note list all unmatched paths when there are only a few, so I can verify exclusions without a separate command.

## s1-logs-b

## 3. Stuck points
No substantial stall. I spent the most time confirming that a `many` input expands into separately ordered command arguments, and that the second `vary` can reduce the server dimension to one fleet report. The guide's text-processing example and dimension-order section answered this.

## 4. Guesses
I assumed `logs/{server}/{date}.log` was narrow enough to exclude the non-daily files. The scan's count and unmatched-file note supported that for the supplied data. The template does not itself validate the date as `YYYY-MM-DD`; I did not find a way to declare that format.

## 5. Guide gaps
I looked in the source path rules and dimension order material for a way to constrain a placeholder to an ISO date. I did not find one. This did not affect the current dataset, but could matter if an unrelated `.log` file appeared in a server folder later.

## 6. Error messages
There were no errors. `Pipeline valid.` plus the resolved path-rule list was useful. The note about three unmatched files was useful, although it only gave one example; listing all three would make exclusion verification quicker.

## 7. Language friction
The pipeline was concise. Strictly expressing "only files whose basename is a YYYY-MM-DD date" seemed awkward or unavailable, so I relied on the path template and inspected the matched count. I also had to use distinct operation and product names (`digest`/`digested`, `rollup`/`weekly`, `fleet`/`fleet_report`), which was mildly unnatural.

## 9. Top three changes
1. Document whether path placeholders can be constrained to filename patterns such as ISO dates, and show a workaround if they cannot.
2. Give a short end-to-end example with two nested `many` rollups and exact command expansion.
3. Let the unmatched-file note list all unmatched paths when the number is small.

## s2-cohort-a

## 3. Stuck points
No long stall. The largest search was finding how SPIT represents a subject exclusion based on session directories. The cohort example and the guide's "Discover contexts from directories" and "Drop groups that fail a criterion" sections answered it.

## 4. Guesses
I inferred that `root data` belonged in the recipe beside `pipeline cohort.spit`; the guide's recipe examples confirmed this. I made no other unconfirmed guesses. The output names and argument order were checked against SPIT's expanded path rules and commands.

## 5. Guide gaps
I found no missing rule needed for this task. The guide's "Dimension order" section explicitly says digit runs sort numerically, and "Paths" describes optional groups used for the output names. The linked cohort example is unusually close to this exact task, so this trial did not test whether I could derive the syntax without it.

## 6. Error messages
There were no error messages. The most useful message was "dropped [sub=03] by `drop [sub] where sessions count<2` (line 5); found 1", because it showed both the excluded subject and the count. The unmatched-files note was useful, though it gave only one example file and required me to infer that the other 23 were sidecars and a top-level file.

## 7. Language friction
The reusable pipeline and dataset recipe required separate files for this small task. The default path with optional groups and `{@stage}` is compact but takes careful reading; SPIT's `--path-rules` output made it practical to verify. No requirement was impossible to express.

## 9. Top three changes
1. Show a concise summary of unmatched files by extension or path category, so irrelevant JSON files are easier to recognize.
2. Offer a command that combines the recipe check, source counts, resolved job counts, and excluded groups in one compact view.
3. Put a direct link to the cohort walkthrough near the first `discover` and `drop` examples in GUIDE.md, since those concepts are needed together.

## s2-cohort-b

## 3. Stuck points

Choosing how to express complete output paths while retaining the exact source labels took the most thought. The cohort example used a shared path template and stages, but this task's names differ by output. Explicit `path` rules for each product resolved it.

## 4. Guesses

I inferred that writing each `.nii.gz` suffix directly in a `path` rule, with no `ext:` declaration, would preserve the exact requested name. `spit check --path-rules` and the rendered commands confirmed it. My only wrong guess was the quick reading of `sub-04`'s session count.

## 5. Guide gaps

I found the needed features in GUIDE.md's discovery, drop, paths, and commands sections. I did not find a single concise example combining fully explicit BIDS output paths and subject-level removal, though the linked cohort example got close.

## 6. Error messages

No errors. The `note: dropped [sub=03] ...; found 1` message was especially helpful because it directly confirmed the study rule. The note about 24 unmatched files was accurate, but it did not break down how many were JSON sidecars versus top-level files; I checked the inventory to confirm they were irrelevant.

## 7. Language friction

The pipeline needs five separate output `path` rules to spell the requested filenames. That is repetitive, but it is straightforward and avoids hidden naming behavior.

## 9. Top three changes

1. Add a compact BIDS example with exact product-specific output paths.
2. Show a summary of ignored files by extension or source of mismatch in the `inputs` note.
3. Add a short recipe pattern for dropping subjects based on session count near the basic `dag` walkthrough.

## s2-followup-a

## Change request

1. **New `sub-06`:** I changed no pipeline or recipe rule. Replanning picked up its two sessions and four runs automatically. This took seconds after the new files appeared, much less time than the first build. The only difficulty was confirming that it was fully included rather than assuming discovery had worked.
2. **Per-session QC:** I added a `qcreport` operation and command, a `qc` step, and its explicit `.html` path. I used a `many` input with `@ vary(run)` and matched the brain for the same subject/session. This took a few minutes, still much less than the first build because the pipeline pattern was already in place. The awkward part was that QC lives directly under the session folder while the other session outputs use stage folders, so it needed its own path rule and had to avoid the pipeline's `.nii.gz` default.
3. **Corrupted run:** I added `exclude bold[sub=02,ses=02,run=3]` to the recipe. This took under a minute. SPIT reported the exclusion and kept it in `plan.spitdag`'s `removed` array. Inspection showed no motion correction or coregistration for that run, and both the session average and QC report use runs 1 and 2 only. The source file stayed in place. This was straightforward once I recognized `exclude` belongs in the recipe.

I regenerated `plan.spitdag` with `spit dag ... -o`. It now has 60 jobs: 8 `bet`, 16 `motioncorr`, 16 `register`, 8 `sessionavg`, 4 `longitudinal`, and 8 `qcreport`. Subject 03 remains dropped. There were no SPIT errors on this change request.

## s2-followup-b

## Change request

1. **New `sub-06`:** I changed no pipeline or recipe rule. I confirmed the two new session directories and regenerated the input inventory and DAG. SPIT discovered four runs and two T1w images automatically. This took under a minute, much less than the first build. Nothing was awkward here.
2. **Per-session QC:** I added one `qcreport` operation and command, one step taking `brain` and `coreg @ vary(run)`, and an explicit `.html` output path. Checking the pipeline and rendered commands took a few minutes, still less than the first build. The multi-input syntax was easy to adapt from the existing averaging step; the output path was another repetitive rule.
3. **Corrupted run:** I added `exclude bold[sub=02,ses=02,run=3]` to the recipe, then regenerated the inventory and DAG without touching the raw file. This took under a minute. The exclusion note was clear, and I verified that neither the average nor QC command has run 3. It was not harder than expected.

The new DAG contains 60 jobs: 16 motion corrections, 8 brain extractions, 16 registrations, 8 averages, 8 QC reports, and 4 longitudinal jobs. Its removal record includes both excluded run 3 and dropped `sub-03`.

## s3-one-board-a

## 3. Stuck points
The most time went into confirming how to cross models with the observed config/seed pairs while keeping seeds correlated with their configs. The ragged sweep example resolved this with `model @ each(model)` and a seed-file source carrying `[config, seed]`.

## 4. Guesses
I used the walkthrough's pattern with a renamed seed source and different command option names. The guide did not explicitly discuss a source named `seed_file` or the `seed-` path prefix, but its general path and placeholder rules covered them. `spit check` and the saved DAG confirmed these choices. No guess turned out wrong.

## 5. Guide gaps
I found the needed rules in the `Write a pipeline` section and the linked language reference and ragged sweep walkthrough. The main guide does not show a complete multi-dimension final aggregate inline; following its links was necessary. A direct example of a final one-file leaderboard in the main guide would have shortened the search.

## 6. Error messages
There were no errors. `Pipeline valid.` was clear, and the DAG's per-step counts made the expansion easy to verify. The `note: found 14 source artifacts` and `note: 39 jobs resolved` messages were useful checks.

## 7. Language friction
The distinction between `@ each(model)` and `@ vary(seed)` took care: `each` broadcasts models into training jobs, while `vary` collects runs. A global `dimensions [model, config, seed]` line is also needed to make the leaderboard order explicit. The walkthrough made this manageable.

## 9. Top three changes
1. Include the ragged sweep's `each`/`vary` pattern and final aggregate in the main guide's pipeline section.
2. Add a concise visual or table showing which input drives a step and how `each` changes the output dimensions.
3. Offer a compact `dag` view that prints just one representative command per step alongside job counts; `--counts` and `--commands` currently require separate inspections for both questions.

## s3-one-board-b

## 3. Stuck points

I did not get stuck. The part that needed the most care was confirming that `model @ each(model)` pairs every model with each observed config/seed file and that the final collection is ordered by model, then config. The worked ragged sweep example explained both, and `--commands` confirmed them for this dataset.

## 4. Guesses

I inferred that names such as `weights`, `metrics`, `summary`, and `board` are arbitrary product names whose `path` rules set the required destinations. The guide's examples support that pattern, and the expanded commands confirmed it. I made no guess that proved wrong.

## 5. Guide gaps

I found no blocking gap. The guide's “Write a pipeline” and “Inspect a dataset and its plan” sections, plus the ragged sweep walkthrough in `docs/examples.md`, covered this task directly.

## 6. Error messages

I encountered no errors. `Pipeline valid.` was clear. The `--counts` output made it easy to detect an accidental Cartesian product over seeds, and `--commands` made argument order and sorting visible.

## 7. Language friction

The split between `each(model)` for the sweep and `vary(seed)` / `vary(model, config)` for aggregation took some reading. The `dimensions [model, config, seed]` declaration also requires knowing that it controls the order of the final many input. I used the documented pattern and verified the resulting commands.

## 9. Top three changes

1. Put a direct link to the ragged sweep walkthrough beside the guide's first explanation of `each` and `vary`.
2. Add a short table showing how `dimensions` affects ordering in a `many` command, including a two-dimension collection.
3. Show one compact `--commands` excerpt beside the ragged sweep example so users can see the final command order without first running it.

## s3-sweep-a

## 3. Stuck points

The most time went into locating the right explanation for crossing models with only the config/seed pairs actually present. The linked ragged sweep walkthrough resolved this: the seed file drives each pair and `model @ each(model)` broadcasts across it.

## 4. Guesses

I inferred that distinct output product names (`weights`, `metrics`, `summary`, `board`, `comparison`) and operation names would work with the same selector pattern as the walkthrough. `spit check` and the displayed commands confirmed it. I made no guess that turned out wrong.

## 5. Guide gaps

I looked in the guide's dimension order and selector sections for this exact ragged model/config/seed case. The guide links a worked example that covers it, so I found no blocking gap. It would help to include one short complete chain with a second, per-model collection before the global collection.

## 6. Error messages

There were no errors. `Pipeline valid.`, `41 jobs resolved.`, and the per-step counts were clear and useful. The commands view was particularly helpful for checking collection order.

## 7. Language friction

`model @ each(model)` reads oddly because the product and dimension share a name, even though the guide explicitly permits it. The operation signatures, five separate output path rules, and five calls were otherwise straightforward. No workaround was needed.

## 9. Top three changes

1. Put a minimal ragged sweep example with two collection levels near the selectors in the main guide.
2. Explain `each` with different product and dimension names before showing the legal same-name case.
3. Add a compact command to validate a saved `.spitdag` against expected per-step counts and command patterns.

## s3-sweep-b

## 3. Stuck points
The only part requiring much thought was expressing every model crossed with only the seeds that actually exist for each config. The guide's ragged sweep walkthrough resolved this directly. It also showed that `dimensions [model, config, seed]` is needed to fix order across otherwise unrelated sources.

## 4. Guesses
I used distinct product and port names, especially `seed_file`, `weights`, and `board`; the guide allows that naming. I inferred that listing `@ vary(config)` and then `@ vary(model)` would produce the two levels of leaderboards. The printed commands confirmed it. No guess turned out wrong.

## 5. Guide gaps
I found no blocking gap. The sections on dimension order and selectors, plus the ragged sweep walkthrough in `docs/examples.md`, covered the core task. A compact example with two consecutive aggregate levels would have made the final two steps easier to recognize at a glance.

## 6. Error messages
There were no SPIT errors. `Pipeline valid.` was clear. The `--counts` output made the expected 41-job total easy to verify, and `--commands` showed the precise arguments in order.

## 7. Language friction
The cross product is expressed by placing `@ each(model)` on the model input while the config/seed input drives the job. That was less obvious from the task statement than a dedicated sweep construct, but the walkthrough explained it. The rest was straightforward.

## 9. Top three changes
1. Put a direct link to the ragged sweep example next to the guide's first explanation of `@ each`.
2. Show a short example of successive `@ vary` aggregations, with the resulting job counts and commands.
3. Add an optional `dag` view grouped by step that prints just the output paths and aggregate input orders, for checking a large plan without reading every command.

## s4-sensors-a

## 3. Stuck points

I spent the most time confirming how to pair each dated baseline with a daily reading without allowing the baseline's date into the output identity. The `same(station)` explanation and the sensors walkthrough resolved it. I did not get stuck on a tool error.

## 4. Guesses

I inferred that naming the baseline's extra dimension `recorded` and using `same(station)` would yield one matching baseline per station. The guide confirms the selector's behavior, and the printed jobs confirmed the chosen files. I also used an untyped pipeline; the guide explicitly allows omitted types. I had no guess turn out wrong.

## 5. Guide gaps

The `Write a pipeline` section gives a compact example, but I needed the `Selectors` section and the linked sensors walkthrough to learn the less common joins. I found the answers there, so I did not find a missing rule. A short link from the first pipeline example to `same` and `where` would make this quicker.

## 6. Error messages

There were no errors. `Pipeline valid.` and the `--path-rules` listing were clear. The unused calibration note was accurate but initially made me pause; it might help if it named the unused revision values alongside the count.

## 7. Language friction

The three joins were concise once I found the selectors. The only awkward part was expressing the baseline as a dated source whose date should be ignored when matching; `@ same(station)` handles it, but its meaning was not obvious from its name alone. I used the example to confirm it. No workaround was needed.

## 9. Top three changes

1. Put a compact `where` / `same` / `vary` example near the first pipeline example in the guide.
2. Have the unused source note list a few identities, such as `calibration[station=north,revision=1]`, so it is immediately clear that only archived revisions were unused.
3. Add an option to show the resolved commands and save the `.spitdag` in one invocation; I used separate `--commands` and `-o` runs to inspect and save the same plan.

## s4-sensors-b

## 3. Stuck points
The baseline's recorded date differs from the reading day, so ordinary dimension matching would not be enough. The guide's sensors example and the `same(station)` reference settled this quickly. This was the only place I paused to inspect the language in depth.

## 4. Guesses
I used `recorded` as the baseline date dimension and inferred it could differ from `day`; the guide confirmed `same(station)` disregards other reference dimensions. I used `Report` as an output type, which is a user-defined type name. I had no guess that turned out wrong.

## 5. Guide gaps
I checked "Write a pipeline" and "Supply the inputs" in `GUIDE.md`, then the linked language reference and sensors walkthrough. I did not find a blocking gap. A compact example of a dated baseline plus a report over irregular ISO-date readings in `GUIDE.md` would have reduced the navigation, although the linked sensors example covers the same selectors.

## 6. Error messages
There were no error messages. "3 source artifacts are used by no job (calibration: 3); `spit artifacts` lists them" was accurate, but at first looked like a potential problem even though archived calibrations must remain unused. "Pipeline valid." and the per-step counts were helpful.

## 7. Language friction
The two joins required different selectors: `where(revision=3)` for a fixed approved revision and `same(station)` for a single baseline whose date is independent of the reading day. Once found, the expressions were concise. I found no impossible requirement.

## 9. Top three changes
1. Put a short `where`/`same`/`vary` example near the first pipeline example in `GUIDE.md`.
2. In the unused-source note, make it clearer that unused archived revisions are acceptable and do not affect job correctness.
3. Show a brief end-to-end verification pattern: `check --path-rules`, `dag --counts`, `dag --commands`, then `dag -o`.

## s4-vague-a

## 3. Stuck points

I spent the most time deciding the join and aggregation syntax. The selector example resolved it: `@ where(revision=3)` pins calibration, `@ same(station)` joins the one baseline per station, and `@ vary(day)` collects anomalies for the report.

## 4. Guesses

I assumed natural ordering of ISO date values is day order. The selector example says `many` inputs arrive in natural order; the printed report commands confirmed the expected order here. I also assumed that untyped source declarations and partly typed operations could coexist; `spit check` confirmed this.

## 5. Guide gaps

I did not find a material gap for this task. The `Write a pipeline` and `Supply the inputs` sections, plus the linked selector example, supplied what I needed. It would still help if `Write a pipeline` showed an explicit example of a single-source station metadata file joining a `many` input.

## 6. Error messages

`error: --counts cannot be used with --commands` was clear and quickly fixed. `note: 3 source artifacts are used by no job (calibration: 3)` was useful confirmation that old revisions stayed unused, though it did not name the revision values in that summary.

## 7. Language friction

The language expressed this task cleanly. The most cognitive work was learning which selector controls each relationship. I used the selector example as a template.

## 9. Top three changes

1. Add a small guide example that combines `where`, `same`, and `vary` in one multi-stage pipeline with filenames.
2. Let `--counts` and `--commands` be combined, or mention their incompatibility in the option table.
3. Make the unused-source summary optionally list the concrete source identities so revision-selection mistakes are easier to spot.

## s4-vague-b

## 3. Stuck points

Choosing the selector for a baseline dated independently of the reading took the most thought. The guide's sensors example used `same(station)` for exactly that arrangement, which resolved it.

## 4. Guesses

I assumed `same(station)` would require exactly one baseline per station and ignore its recorded date. The guide confirmed that. I also relied on a `many` input with `vary(day)` to produce naturally ordered arguments; the guide confirmed ISO date ordering and the command listing showed it.

## 5. Guide gaps

I did not find a missing feature explanation for this task. I checked “Products and dimensions,” “Operations and commands,” “Paths,” and the sensors walkthrough. The guide did not make the prohibition of `: one` as obvious as `: many` until the compiler explained it.

## 6. Error messages

“An input takes one artifact unless it says `many`; write `cal`” was useful because it supplied the exact fix. “--counts cannot be used with --commands” was clear, though I initially expected both inspection options to compose. The unused calibration note was helpful evidence that older revisions were excluded.

## 7. Language friction

I wanted to annotate single inputs with `one` for readability, but the syntax requires the bare port name. The workaround was to omit the annotation. The baseline join itself was concise once I found `same(station)`.

## 9. Top three changes

1. Show `port` versus `port: many` explicitly together in the first operation example.
2. Let `--counts` and `--commands` work together, or mention their incompatibility in help.
3. Put the `same(station)` pattern for a baseline filed under an unrelated date near the first selector explanation.

## s5-survey-a

## 3. Stuck points
I spent the longest time confirming the right syntax for the two outputs from one model job, and that `verify` would run before the fit with the same ordered `many` input. The guide's operations section and the sensors example resolved both.

## 4. Guesses
I used `Responses`, `Coefficients`, `Diagnostics`, `Chart`, and `Table` as logical types without knowing whether that added value for a planning-only exercise. This worked. I also relied on the guide's statement that source paths match the whole filename to ignore `.csv.bak`; the planner's unmatched-file note confirmed it.

## 5. Guide gaps
I checked the Stages, Operations and commands, and Paths sections. I did not find a single concise example combining three stages, two outputs, `verify` on a `many` input, and an aggregate over a second dimension. The ingredients were documented separately and were enough to finish.

## 6. Error messages
No error messages occurred. `Pipeline valid.` and the `20 jobs resolved` count were useful. The unmatched backup note was especially useful because it named the exact ignored file. `--commands` displayed the validation line directly above each fit line, making the safety requirement easy to check.

## 7. Language friction
The language expressed this pipeline directly. I had to name a product for `diag` even though no downstream job reads it, which is reasonable because it is a required output. I used explicit paths for every product because the requested folder structure does not fit one default template cleanly.

## 9. Top three changes
1. Add a compact example of staged ingest/model/publish work with a guarded multi-output aggregate.
2. Put the natural numeric ordering rule next to the first `@ vary` example, since ordering can affect scientific results.
3. Add a short verification checklist in the guide: `check`, `dag --counts`, then `dag --commands` before saving or using the plan.

## s5-survey-b

## 3. Stuck points
The longest part was finding the exact syntax for a single operation with two outputs and a `many` input guarded by `verify`. The language reference's Operations and commands section resolved it.

## 4. Guesses
I used untyped products and explicit `.csv`, `.json`, `.txt`, and `.svg` output extensions. The guide permits untyped products and output extensions, and `spit check` accepted them. I initially expected the backup to appear as unmatched; the planner confirmed it did. No guess turned out wrong.

## 5. Guide gaps
No blocking gap. In `GUIDE.md`'s Write a pipeline section, the introductory example did not combine stages, `many`, two outputs, and `verify`; I had to follow links into the language reference and inspect several sections. A compact example matching this combination would help.

## 6. Error messages
There were no errors. `Pipeline valid.` was clear. The unmatched-file note was useful because it explicitly identified `wave3.csv.bak`, though `1 files` is grammatically awkward.

## 7. Language friction
None blocked this task. Explicit `path` lines for each product were repetitive but made the requested layout easy to audit. I had to name both fit outputs as ports and assign both products in one step.

## 9. Top three changes
1. Put a concise combined example of stages, `many`, multiple outputs, and `verify` in the main guide.
2. Add a command that displays the resolved pipeline as a compact per-stage summary with representative commands and argument ordering.
3. Fix the unmatched-file note's singular grammar (`1 file`).

## s6-diagnose-a

## 3. Stuck points

Choosing how to omit `s07` without leaving `S07` as an unused source took the most thought. The guide's explanation that drop groups form from every source artifact clarified it. `drop [store] where sales count<2` removes `S07` and `s03`; `drop [store] where pricing count=0` removes `s07` and `s09`.

## 4. Guesses

I guessed that these two drop rules would evaluate against the original inventory independently and leave exactly the healthy stores. The guide confirmed the evaluation order and `spit inputs` confirmed the actual removals. No guess turned out wrong.

## 5. Guide gaps

I looked in GUIDE.md's Recipes and Drop groups sections. I found the syntax I needed; no specific missing explanation blocked this task. A worked example combining a case-mismatched source with group drops would have made the `S07` extra group more obvious.

## 6. Error messages

There were no errors. The artifact message was particularly useful: “`pricing[store=S07] exists; its store differs only in letter case`.” The message for `s03` also gave the exact cardinality failure: “`needs at least 2 artifacts at [store=s03], found 1`.”

## 7. Language friction

The goal was to remove stores based on whether their final reports can be produced. The recipe language cannot directly say “drop stores with incomplete reports”; I expressed the two underlying source conditions instead. This was straightforward here, but it duplicates knowledge of the pipeline's two-week threshold in the recipe.

## 9. Top three changes

1. Offer an `artifacts` view grouped by failed final target, with root causes nested under each store report.
2. Suggest recipe rules for common failures such as missing joined sources or insufficient counts, while letting the user review them.
3. Show case-only identity groups together in `inputs` output, so `s07` and `S07` are immediately visible as related.

## s6-diagnose-b

## 3. Stuck points

The longest pause was deciding whether to leave the mismatched uppercase price list in the input inventory. I excluded it so the plan contains only sources for participating stores.

## 4. Guesses

I guessed that a store report should be considered impossible for s03 even though its single revenue job is valid; the `@ min(2)` declaration and artifact report confirmed it. I also inferred that excludes are case sensitive; the first plan's unused-source note confirmed that.

## 5. Guide gaps

In the guide's "Supply the inputs" and "Drop groups that fail a criterion" sections, I looked for a direct recipe for diagnosing a full report chain before choosing exclusions. The `artifacts` command description provided the needed approach, but a worked example of diagnosing then excluding groups would be helpful.

## 6. Error messages

No SPIT command failed. The best diagnostic was: "pricing[store=S07] exists; its `store` differs only in letter case". It identified the exact mismatch. The first plan's "1 source artifact is used by no job (pricing: 1)" was accurate but required another lookup to see which source it meant.

## 7. Language friction

One exclusion for `[store=s07]` did not also remove the related `pricing[store=S07]`; I had to add `[store=S07]`. This is consistent with case sensitive identities, but the business concept of one store split into two identities.

## 9. Top three changes

1. Add a short diagnosis and exclusion walkthrough centered on `spit artifacts`.
2. When `dag` reports unused sources, show the identities in that note or suggest the specific `artifacts` lookup.
3. Offer a concise summary of incomplete final artifacts by group, alongside the detailed artifact listing.
